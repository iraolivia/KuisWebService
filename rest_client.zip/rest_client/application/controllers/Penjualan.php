<?php
Class Penjualan extends CI_Controller{
    
    var $API ="";
    
    function __construct() {
        parent::__construct();
        $this->API="http://localhost/rest_server/index.php";
    }
    
    // menampilkan data penjualan
    function index(){
        $data['penjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan'));
        $this->load->view('penjualan/list',$data);
    }
    
    // insert data penjualan
    function create(){
        if(isset($_POST['submit'])){
            $data = array(
                'kode_barang'       =>  $this->input->post('kode'),
                'nama_barang'      =>  $this->input->post('nama'),
                'jumlah_barang'=>  $this->input->post('jumlah'),
                'harga_barang'    =>  $this->input->post('harga'));
            $insert =  $this->curl->simple_post($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($insert)
            {
                $this->session->set_flashdata('hasil','Insert Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Insert Data Gagal');
            }
            redirect('penjualan');
        }else{
            $data['jumlah'] = json_decode($this->curl->simple_get($this->API.'/jumlah'));
            $this->load->view('penjualan/create',$data);
        }
    }
    
    // edit data penjualan
    function edit(){
        if(isset($_POST['submit'])){
            $data = array(
                'kode_barang'       =>  $this->input->post('kode'),
                'nama_barang'      =>  $this->input->post('nama'),
                'jumlah_barang'=>  $this->input->post('jumlah'),
                'harga_barang'    =>  $this->input->post('harga'));
            $update =  $this->curl->simple_put($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($update)
            {
                $this->session->set_flashdata('hasil','Update Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Update Data Gagal');
            }
            redirect('penjualan');
        }else{
            $data['jumlah'] = json_decode($this->curl->simple_get($this->API.'/jumlah'));
            $params = array('kode_barang'=>  $this->uri->segment(3));
            $data['penjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan',$params));
            $this->load->view('penjualan/edit',$data);
        }
    }
    
    // delete data penjualan
    function delete($nim){
        if(empty($nim)){
            redirect('penjualan');
        }else{
            $delete =  $this->curl->simple_delete($this->API.'/penjualan', array('kode_penjualan'=>$nim), array(CURLOPT_BUFFERSIZE => 10)); 
            if($delete)
            {
                $this->session->set_flashdata('hasil','Delete Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Delete Data Gagal');
            }
            redirect('penjualan');
        }
    }
}