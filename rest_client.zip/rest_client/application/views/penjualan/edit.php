<?php echo form_open('penjualan/edit');?>
<?php echo form_hidden('kode_barang',$penjualan[0]->kode);?>

<table>
    <tr><td>KODE BARANG</td><td><?php echo form_input('kode_barang',$penjualan[0]->kode,"disabled");?></td></tr>
    <tr><td>NAMA BARANG</td><td><?php echo form_input('nama_barang',$penjualan[0]->nama);?></td></tr>
    <tr><td>JUMLAH BARANG</td><td>
            <select name="jumlah_barang">
            <?php
            foreach ($jumlah as $j){
                echo "<option value='$j->jumlah_barang' ";
                echo $penjualan[0]->jumlah_barangn==$j->jumlah_barang?'selected':'';
                echo ">$j->stok_barang</option>";
            }
            ?>
            </select>
        </td></tr>
    <tr><td>HARGA BARANG</td><td><?php echo form_input('harga_barang',$penjualan[0]->alamat);?></td></tr>
    <tr><td colspan="2">
        <?php echo form_submit('submit','Simpan');?>
        <?php echo anchor('penjualan','Kembali');?></td></tr>
</table>
<?php
echo form_close();
?>