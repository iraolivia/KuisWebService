<?php echo form_open('penjualan/create');?>
<table>
    <tr><td>KODE BARANG</td><td><?php echo form_input('kode_barang');?></td></tr>
    <tr><td>NAMA BARANG</td><td><?php echo form_input('nama_barang');?></td></tr>
    <tr><td>JUMLAH BARANG</td><td>
            <select name="jumlah_barang">
            <?php
            foreach ($jumlah as $j){
                echo "<option value='$j->jumlah_barang'>$j->stok_barang</option>";
            }
            ?>
            </select>
        </td></tr>
    <tr><td>HARGA BARANG</td><td><?php echo form_input('harga_barang');?></td></tr>
    <tr><td colspan="2">
        <?php echo form_submit('submit','Simpan');?>
        <?php echo anchor('penjualan','Kembali');?></td></tr>
</table>
<?php
echo form_close();
?>