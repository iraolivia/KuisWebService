<?php echo $this->session->flashdata('hasil'); ?>
<table>
    <tr><th>KODE BARANG</th><th>NAMA BARANG</th><th>JUMLAH BARANG</th><th>HARGA BARANG</th><th></th></tr>
    <?php
    foreach ($penjualan as $m){
        echo "<tr>
              <td>$m->kode_barang</td>
              <td>$m->nama_barang</td>
              <td>$m->jumlah_barang</td>
              <td>$m->harga_barang</td>
              <td>".anchor('penjualan/edit/'.$m->nim,'Edit')."
                  ".anchor('penjualan/delete/'.$m->nim,'Delete')."</td>
              </tr>";
    }
    ?>
</table>